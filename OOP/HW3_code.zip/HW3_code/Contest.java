/**
 * Write a description of class Contest here.
 * 
 * @author (your name)
 * @version (a version number or a date)
 */
public class Contest
{
    /**
     * Constructor for objects of class Contest
     */
    public Contest()
    {
       
    }
}
